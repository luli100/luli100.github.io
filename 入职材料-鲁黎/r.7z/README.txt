The 'h' folder contains links to the more human readable
build folders done with a Windows directory junction.

We are doing this to reduce the path lengths during builds
so that we don't hit the Windows path length limit so
quickly.
This is why you will see only the 'h' folders in the build
logs.

If we come up with a better solution we might remove it
again so don't rely on it.
This is a linked folder (directory junction) and links
   D:\continental\RAD6XX_DevEnv\BuildUnits\RAD6XX_DPU\conan_workarea\h\83c02115bd1b90338e80b9ef26929f9c with
  D:\continental\RAD6XX_DevEnv\BuildUnits\RAD6XX_DPU\conan_workarea\build.adas_rad_det_img.ars620_objkinematics_sil.8.0.0-fallback.vs2017_debug\cip_build
